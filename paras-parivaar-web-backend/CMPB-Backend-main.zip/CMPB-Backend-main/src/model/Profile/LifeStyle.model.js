import mongoose, { Schema } from "mongoose";

const LifeStyleSchema = new mongoose.Schema({
  ProfileID: {
    type: Schema.Types.ObjectId,
    ref: "profiles",
  },
  Diet: {
    type: Boolean,
    required: true,
  },
  Drink: {
    type: Boolean,
    required: true,
  },
  Smoke: {
    type: Boolean,
    required: true,
  },
  LivingWith: {
    type: String,
    required: true,
  },
});

export const LifeStyleModel = mongoose.model("lifestyles", LifeStyleSchema);
