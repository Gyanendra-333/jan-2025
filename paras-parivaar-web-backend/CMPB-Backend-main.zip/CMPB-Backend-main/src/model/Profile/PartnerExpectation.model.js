import mongoose, { Schema } from "mongoose";

const partnerExpectationSchema = new mongoose.Schema({
  ProfileID: {
    type: Schema.Types.ObjectId,
    ref: "profiles",
  },
  GernalRequirement: {
    type: String,
    required: true,
    trim: true,
  },

  ResidenceCountry: {
    type: String,
    required: true,
    trim: true,
  },
  Height: {
    type: Number,
    required: true,
    trim: true,
  },

  weight: {
    type: Number,
    required: true,
    trim: true,
  },
  MaritalStatus: {
    type: String,
    required: true,
    trim: true,
  },
  Children: {
    type: Number,
    required: true,
    trim: true,
  },
  Religion: {
    type: String,
    required: true,
    trim: true,
  },
  Caste: {
    type: String,
    required: true,
    trim: true,
  },
  SubCaste: {
    type: String,
    required: true,
    trim: true,
  },
  Language: {
    type: String,
    required: true,
    trim: true,
  },
  Education: {
    type: String,
    required: true,
    trim: true,
  },
  Profession: {
    type: String,
    required: true,
    trim: true,
  },
  SmokingAcceptable: {
    type: String,
    required: true,
    trim: true,
  },
  DietAcceptable: {
    type: String,
    required: true,
    trim: true,
  },
  DrinkAcceptable: {
    type: String,
    required: true,
    trim: true,
  },
  personalValue: {
    type: Number,
    required: true,
    trim: true,
  },
  Manglik: {
    type: String,
    required: true,
    trim: true,
  },
  PreferredCountry: {
    type: String,
    required: true,
    trim: true,
  },
  PreferredState: {
    type: String,
    required: true,
    trim: true,
  },
  FamilyValue: {
    type: Number,
    required: true,
    trim: true,
  },
  Complexion: {
    type: String,
    required: true,
    trim: true,
  },
});

export const PartnerExpectationModel = mongoose.model(
  "partnerexpectations",
  partnerExpectationSchema
);
