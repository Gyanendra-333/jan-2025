import mongoose, { Schema } from "mongoose";

const educationSchema = new mongoose.Schema({
  ProfileID: {
    type: Schema.Types.ObjectId,
    ref: "profiles",
  },
  Degree: {
    type: String,
    required: true,
    trim: true,
  },
  insitution: {
    type: String,
    required: true,
    trim: true,
  },
  start: {
    type: String,
    required: true,
    trim: true,
  },
  end: {
    type: String,
    required: true,
    trim: true,
  },
});

export const EducationModel = mongoose.model("educations", educationSchema);
