import mongoose, { Schema } from "mongoose";

const residencyInfoSchema = new mongoose.Schema({
  ProfileID: {
    type: Schema.Types.ObjectId,
    ref: "profiles",
  },
  birthCounty: {
    type: String,
    required: true,
    trim: true,
  },
  residencyCounty: {
    type: String,
    required: true,
    trim: true,
  },
  grownUpCountry: {
    type: String,
    required: true,
    trim: true,
  },
  ImmigrationStatus: {
    type: String,
    required: true,
    trim: true,
  },
});

export const residencyInfosModal = mongoose.model(
  "residencyinfos",
  residencyInfoSchema
);
