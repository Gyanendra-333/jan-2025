#.

```
git config user.name "parasparivaarbackend"
git config user.email "parasjisco@gmail.com"


database model and drawing

https://excalidraw.com/#json=dnKmslKRTmBP8v1MvD7oL,qxdHu0D4iOLbp1rfB1AX_A

//for node environment
"build": "bun build src/index.ts --outdir dist",
"start": "node -r dotenv/config dist/index.js"

"build2": "tsc", // it will not work because build will be handle by bun

ecosystem.config.js //use in production with pm2
```

```
 bunx eslint .

 eslint restart server in vscode command palette


 migration command keys are written in script folder


 npm i npm-check-update -g //install as global dependency on system to check update for all projects
 ncu //then use this to check update for the project that is currently open
 ncu -u // to update it will update in package.json but wont install
 npm i //then install
```

```
"feat": Adding a new feature
"fix": Fixing a bug
"docs": Updating documentation
"style": Changes related to styling (CSS, formatting, missing semicolons, etc.), without affecting functionality
"refactor": Code refactoring without changing functionality
"perf": Performance improvement in the application
"test": Adding, modifying, or fixing test cases
"build": Changes affecting the build system or dependencies (e.g., webpack, npm, yarn)
"ci": Changes related to continuous integration (e.g., GitHub Actions, Jenkins, TravisCI)
"chore": Routine tasks or maintenance (e.g., updating dependencies, cleaning up code)
"revert": Reverting a previous commit
```

```
Docker
Development

docker build -t news-backend:dev -f docker/development/Dockerfile .
docker run --rm -it -v ${PWD}:/usr/src/news-development -v /usr/src/news-backend/node_modules -p 3000:3000  news-backend:dev

Production

docker build -t news-backend:prod -f docker/production/Dockerfile .
docker run --rm -d -v ${PWD}:/usr/src/news-development -v /usr/src/news-backend/node_modules -p 3000:3000 news-backend:1.0.0


```

```
//legecy watch flag that will make changes to docker when make changes to code
// jb bhi humara docker container sync hota h humare iss particular machine ki directory k sath toh yaha pe jo nodemon h vo aksar kaam nhi krta 'so usi k liye flag lgaya h' so ab hum jb bhi kuch change kregy src k andar toh vo docker k andar bhi restart ho jayega and sync bhi

"dev": "cross-env NODE_ENV=development nodemon --legacy-watch src/server.ts",
```

```

${PWD}:/usr/src/news-development -v /usr/src/news-backend/node_modules -p 3000:3000

news-development is from dockerfile set under WORKDIR
news-backend is our project folder name
this command is to ignore node_modules = -v /usr/src/news-backend/node_modules

this is called mount binding

```
```
husky

bunx husky init

Ensure Git Hooks Are Set Up
Check if Git hooks are properly installed:

git config core.hooksPath   //to check

It should return .husky/. If not, set it manually:

git config core.hooksPath .husky


```