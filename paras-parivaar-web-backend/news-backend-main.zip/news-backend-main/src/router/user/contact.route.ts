import { Router } from "express";
import { createContact } from "../../controller/contact.controller";
import { Validator } from "../../validation/indexValidation";
import { ConatctSchema } from "../../validation/validationSchema";
import rateLimiter from "../../middleware/rateLimiter";

const router = Router();
const conatctValidator = new Validator(ConatctSchema);

router
  .route("/create")
  .post(rateLimiter.strict, conatctValidator.validate, createContact);

export default router;
