import { Router } from "express";
import {
  abc,
  categoryList,
  // getAllnewsByCategory,
  getNewsBySlug,
  LatestpublicNews,
  RelatedNews,
} from "../../controller/publicNews.controller";

const router = Router();

//Category
router.route("/category-list").get(categoryList);

//News
router.route("/get/?").get(LatestpublicNews);
router.route("/news/:slug").get(getNewsBySlug);
router.route("/related-news/?").get(RelatedNews);
// router.route("/get/category/?").get(getAllnewsByCategory);
// router.route("/get/:category/:subcategory").get(getAllnewsByCategory);
router.route("/get/:category/:subcategory/?").get(abc);

export default router;
