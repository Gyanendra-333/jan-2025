import { Router } from "express";

import rateLimiter from "../middleware/rateLimiter";
import publisherRoute from "../router/admin/publisher.route";
import categoryRoute from "../router/admin/category.route";
import anchorRoute from "../router/admin/anchor.route";
import adminContactRoute from "../router/admin/contact.route";
import contactRoute from "../router/user/contact.route";
import subCategoryRoute from "../router/admin/subCategory.route";
import newsRoute from "../router/admin/news.route";
import healthCheck from "../controller/healthCheck.controller";
import authRoute from "../router/admin/auth.route";
import publicRoute from "../router/user/public.route";
import dashboardRoute from "../router/admin/dashboard.route";
import verifyJWT from "../middleware/auth.middleware";

const router = Router();

router.use("/publisher", rateLimiter.flexible, verifyJWT, publisherRoute);
router.use("/anchor", rateLimiter.flexible, verifyJWT, anchorRoute);
router.use("/category", rateLimiter.flexible, verifyJWT, categoryRoute);
router.use("/subCategory", rateLimiter.flexible, verifyJWT, subCategoryRoute);
router.use("/news", rateLimiter.flexible, verifyJWT, newsRoute);
router.use("/dashboard", rateLimiter.flexible, verifyJWT, dashboardRoute);
router.use("/auth", rateLimiter.strict, authRoute);
router.use("/u", rateLimiter.public, publicRoute);
router.use("/admin-contact", verifyJWT, adminContactRoute);
router.use("/contact", contactRoute);

//health check
router.route("/health").get(rateLimiter.strict, healthCheck);

export default router;
