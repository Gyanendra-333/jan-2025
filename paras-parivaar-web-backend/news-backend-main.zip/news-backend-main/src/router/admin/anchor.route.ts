import { Router } from "express";
import {
  createAcnhor,
  updateAnchor,
  deleteAnchor,
  getAnchor,
} from "../../controller/anchor.controller";
import { Validator } from "../../validation/indexValidation";
import { AnchorSchema } from "../../validation/validationSchema";


const router = Router();
const anchorValidator = new Validator(AnchorSchema);

router.route("/create").post(anchorValidator.validate, createAcnhor);
router.route("/update/:id").put(anchorValidator.validate, updateAnchor);
router.route("/delete/:id").delete(deleteAnchor);
router.route("/get").get(getAnchor);

export default router;
