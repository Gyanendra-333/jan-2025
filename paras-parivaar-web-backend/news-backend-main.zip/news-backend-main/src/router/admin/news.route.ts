import { Router } from "express";
import {
  createNews,
  UpdateNews,
  deleteNews,
  getNews,
  getNewsByID,
} from "../../controller/news.controller";
import { Validator } from "../../validation/indexValidation";
import { NewsSchema } from "../../validation/validationSchema";
import { upload } from "../../middleware/multer.middleware";

const router = Router();

const newsValidator = new Validator(NewsSchema);
router.route("/create").post(upload, newsValidator.validate, createNews);
router.route("/update/:id").put(upload, newsValidator.validate, UpdateNews);
router.route("/delete/:id").delete(deleteNews);
router.route("/get").get(getNews);
router.route("/get/:id").get(getNewsByID);

export default router;
