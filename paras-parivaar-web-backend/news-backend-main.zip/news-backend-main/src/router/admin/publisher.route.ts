import { Router } from "express";
import {
  createPublisher,
  updatePublisher,
  deletePublisher,
  getPublisher,
} from "../../controller/publisher.controller";
import { Validator } from "../../validation/indexValidation";
import { PublisherSchema } from "../../validation/validationSchema";

const router = Router();

const publisherValidator = new Validator(PublisherSchema);

router.route("/create").post(publisherValidator.validate, createPublisher);
router.route("/update/:id").put(publisherValidator.validate, updatePublisher);
router.route("/delete/:id").delete(deletePublisher);
router.route("/get").get( getPublisher);

export default router;
