import { Router } from "express";
import {
  adminLogin,
  Adminlogout,
  adminSignUp,
  changePassword,
  forgetPassword,
  refreshAccessToken,
  verifyOTP,
} from "../../controller/Auth.controller";
import verifyJWT from "../../middleware/auth.middleware";

const router = Router();

router.route("/admin/signup?").post(adminSignUp);
router.route("/signup").post(adminSignUp);
router.route("/login").post(adminLogin);
router.route("/verify").post(verifyOTP);
router.route("/forget-password").post(forgetPassword);
router.route("/refresh-token").post(refreshAccessToken);

//with middleware
router.route("/logout").post(verifyJWT, Adminlogout);
router.route("/change-password").post(verifyJWT, changePassword);

export default router;
