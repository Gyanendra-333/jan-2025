import { Router } from "express";
import {
  createCategory,
  deleteCategory,
  getCategory,
  updatecategory,
} from "../../controller/category.controller";
import { CategorySchema } from "../../validation/validationSchema";
import { Validator } from "../../validation/indexValidation";

const router = Router();
const categoryValidator = new Validator(CategorySchema);

router.route("/create").post(categoryValidator.validate, createCategory);
router.route("/update/:id").put(categoryValidator.validate, updatecategory);
router.route("/get").get(getCategory);
router.route("/delete/:id").delete(deleteCategory);

export default router;
