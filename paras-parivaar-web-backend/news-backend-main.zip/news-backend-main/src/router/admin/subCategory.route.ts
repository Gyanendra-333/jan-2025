import { Router } from "express";
import {
  createSubcategory,
  deleteSubCategory,
  updateSubCategory,
  getSubCategoryList,
  getSubCategory,
} from "../../controller/subcategory.controller";
import { SubcategorySchema } from "../../validation/validationSchema";
import { Validator } from "../../validation/indexValidation";

const router = Router();

const subcategoryValidator = new Validator(SubcategorySchema);
router.route("/create").post(subcategoryValidator.validate, createSubcategory);
router
  .route("/update/:id")
  .put(subcategoryValidator.validate, updateSubCategory);
router.route("/delete/:id").delete(deleteSubCategory);
router.route("/get-list").get(getSubCategoryList);
router.route("/get/:categoryId").get(getSubCategory);

export default router;
