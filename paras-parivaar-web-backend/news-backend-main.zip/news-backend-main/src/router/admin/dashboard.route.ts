import { Router } from "express";
import { DashboardCards, popularNews } from "../../controller/dashboard.controller";

const router = Router();
router.route("/cards").get(DashboardCards);
router.route("/popular-news").get(popularNews);

export default router;
