import { Router } from "express";
import { getConatctDetails } from "../../controller/contact.controller";

const router = Router();

router.route("/get").get(getConatctDetails);

export default router;
