import type { Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { PublisherModel } from "../model/publisher.model";
import { ApiError } from "../utlis/ApiError";
import { ApiResponse } from "../utlis/ApiResponse";

const createPublisher = asyncHandler(async (req: Request, res: Response) => {
  const data = req.body as { name: string };
  try {
    const publisher = await PublisherModel.create(data);
    if (!publisher) {
      return res
        .status(400)
        .json(new ApiError(400, "Publisher Name is required", req));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "Publisher Created Successfully", publisher));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// update publisher

const updatePublisher = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  // const { name } = req.body as { name: string };
  const data = req.body as { name: string };

  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Failed to update publisher ", req));
  }

  try {
    const updatedpublisher = await PublisherModel.findByIdAndUpdate(
      { _id: id },
      { ...data },
      { new: true }
    );
    if (!updatedpublisher) {
      return res
        .status(400)
        .json(new ApiError(400, "Failed to update publisher", req));
    }

    return res
      .status(200)
      .json(
        new ApiResponse(200, "Publisher Update Successfully", updatedpublisher)
      );
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// delete publisher

const deletePublisher = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Failed to delete publisher ", req));
  }

  try {
    const deletedPublisher = await PublisherModel.findByIdAndDelete({
      _id: id,
    });
    if (!deletedPublisher) {
      return res
        .status(400)
        .json(new ApiError(400, "Failed to delete publisher ", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Publisher delete Successfully", null));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// display publisher

const getPublisher = asyncHandler(async (req: Request, res: Response) => {
  try {
    const showPublisher = await PublisherModel.find();

    if (showPublisher.length === 0) {
      return res
        .status(400)
        .json(new ApiError(400, "Publisher not found", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Publisher show Successfully", showPublisher));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});
export { createPublisher, updatePublisher, deletePublisher, getPublisher };
