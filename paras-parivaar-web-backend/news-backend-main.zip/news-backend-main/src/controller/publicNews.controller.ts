import type { Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiResponse } from "../utlis/ApiResponse";
import { ApiError } from "../utlis/ApiError";
import { NewsModel } from "../model/news.model";
import { CategoryModel } from "../model/category.model";

//Homepage navbar category
const categoryList = asyncHandler(async (req: Request, res: Response) => {
  try {
    const data = await CategoryModel.aggregate([
      {
        $lookup: {
          localField: "_id",
          foreignField: "categoryId",
          from: "subcategories",
          as: "subcategory",
        },
      },
    ]);

    if (data?.length === 0) {
      return res.status(200).json(new ApiResponse(200, "No data exist", []));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Category list data", data));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

type queryType = {
  category: string;
  subcategory: string;
  publisher: string;
  anchor: string;
  page: string;
  limit: string;
};

const LatestpublicNews = asyncHandler(async (req: Request, res: Response) => {
  try {
    const query = req.query as queryType;
    const category = query?.category;
    const subcategory = query?.subcategory;
    const publisher = query?.publisher;
    const anchor = query?.anchor;
    const page = Number(query?.page) || 1;
    const limit = Number(query?.limit) || 5;
    const newLimit = page * limit;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const pipeline: any[] = [
      { $match: { status: true } },
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "_id",
          as: "category",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$category" },
    ];
    if (category && category !== "null" && category != "undefined") {
      pipeline.push({ $match: { "category.name": category } });
    }

    pipeline.push(
      {
        $lookup: {
          from: "subcategories",
          localField: "subCategoryId",
          foreignField: "_id",
          as: "subcategory",
          pipeline: [
            {
              $project: {
                name: 1,
                categoryId: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$subcategory",
          preserveNullAndEmptyArrays: true,
        },
      }
    );
    if (
      category &&
      subcategory &&
      category !== "null" &&
      category != "undefined" &&
      subcategory != "null" &&
      subcategory !== "undefined"
    ) {
      pipeline.push(
        { $match: { "subcategory.name": subcategory } },
        {
          $match: {
            $expr: {
              $eq: ["$category._id", "$subcategory.categoryId"],
            },
          },
        }
      );
    } else if (
      (!category || subcategory) &&
      subcategory != "null" &&
      subcategory !== "undefined"
    ) {
      pipeline.push({ $match: { "subcategory.name": subcategory } });
    }

    pipeline.push(
      {
        $lookup: {
          from: "publishers",
          localField: "publisherId",
          foreignField: "_id",
          as: "publisher",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$publisher" }
    );

    if (publisher && publisher !== "null" && publisher != "undefined") {
      pipeline.push({ $match: { "publisher.name": publisher } });
    }
    pipeline.push(
      {
        $lookup: {
          from: "anchors",
          localField: "anchorId",
          foreignField: "_id",
          as: "anchor",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$anchor" }
    );

    if (anchor && anchor !== "null" && anchor != "undefined") {
      pipeline.push({ $match: { "anchor.name": anchor } });
    }
    pipeline.push({
      $project: {
        title: 1,
        slug: 1,
        metaDesciption: 1,
        description: 1,
        type: 1,
        videoURL: 1,
        Image: 1,
        alt: 1,
        status: 1,
        tags: 1,
        views: 1,
        category: 1,
        subcategory: 1,
        publisher: 1,
        anchor: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    });

    const news = await NewsModel.aggregate(pipeline)
      .sort({ createdAt: -1 })
      .limit(newLimit);

    return res.status(200).json(new ApiResponse(200, "News data fetch", news));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const getAllnewsByCategory = asyncHandler(
  async (req: Request, res: Response) => {
    const { query } = req;
    const category = query.category;
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 5;
    const newLimit = limit * page;

    try {
      const news = await NewsModel.aggregate([
        { $match: { status: true } },
        {
          $lookup: {
            from: "categories",
            localField: "categoryId",
            foreignField: "_id",
            as: "category",
          },
        },
        { $unwind: "$category" },
        { $match: { "category.name": category } },
      ])
        .limit(newLimit)
        .sort({ createdAt: -1 });

      return res.status(200).json(new ApiResponse(200, "news fetch", news));
    } catch (error) {
      return res
        .status(500)
        .json(new ApiError(500, "Something went wrong", req, [error]));
    }
  }
);

const abc = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { category, subcategory } = req.params;
    const { page = 0, limit = 1 } = req.query;

    const news = await NewsModel.aggregate([
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "_id",
          as: "category",
        },
      },
      {
        $lookup: {
          from: "subcategories",
          localField: "subCategoryId",
          foreignField: "_id",
          as: "subcategory",
        },
      },
      { $unwind: "$category" },
      { $match: { "category.name": category } },
      { $unwind: "$subcategory" },
      { $match: { "subcategory.name": subcategory } },
    ])
      .sort({ createdAt: -1 })
      .skip(Number(page))
      .limit(Number(limit));

    return res.status(200).json(new ApiResponse(200, "news data", news));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const getNewsBySlug = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;

    await NewsModel.findOneAndUpdate(
      { slug: slug, status: true },
      { $inc: { views: 1 } }
    );

    const news = await NewsModel.aggregate([
      {
        $match: { slug: slug, status: true },
      },
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "_id",
          as: "category",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$category" },
      {
        $lookup: {
          from: "subcategories",
          localField: "subCategoryId",
          foreignField: "_id",
          as: "subcategory",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$subcategory",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "publishers",
          localField: "publisherId",
          foreignField: "_id",
          as: "publisher",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$publisher" },
      {
        $lookup: {
          from: "publishers",
          localField: "publisherId",
          foreignField: "_id",
          as: "publisher",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$publisher" },
      {
        $lookup: {
          from: "anchors",
          localField: "anchorId",
          foreignField: "_id",
          as: "anchor",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$anchor" },

      {
        $project: {
          title: 1,
          slug: 1,
          description: 1,
          metaDesciption: 1,
          type: 1,
          videoURL: 1,
          Image: 1,
          alt: 1,
          status: 1,
          views: 1,
          category: 1,
          subcategory: 1,
          publisher: 1,
          anchor: 1,
          createdAt: 1,
          updatedAt: 1,
        },
      },
    ]);

    if (!news) {
      return res.status(200).json(new ApiResponse(200, "No data found", {}));
    }

    return res.status(200).json(new ApiResponse(200, "news data fetch", news));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const RelatedNews = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { query } = req;
    const category = query.category;

    if (!category || category === "null" || category === "undefined") {
      return res
        .status(200)
        .json(new ApiResponse(200, "category or subcategory is required", []));
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const pipeline: any[] = [
      { $match: { status: true } },
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "_id",
          as: "category",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$category" },
    ];
    if (category && category !== "null" && category != "undefined") {
      pipeline.push({ $match: { "category.name": category } });
    }
    pipeline.push(
      {
        $lookup: {
          from: "subcategories",
          localField: "subCategoryId",
          foreignField: "_id",
          as: "subcategory",
          pipeline: [
            {
              $project: {
                name: 1,
                categoryId: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$subcategory",
          preserveNullAndEmptyArrays: true,
        },
      }
    );

    pipeline.push({
      $project: {
        title: 1,
        slug: 1,
        metaDesciption: 1,
        description: 1,
        type: 1,
        videoURL: 1,
        Image: 1,
        alt: 1,
        status: 1,
        tags: 1,
        views: 1,
        category: 1,
        subcategory: 1,
        publisher: 1,
        anchor: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    });

    const relatedNews = await NewsModel.aggregate(pipeline)
      .sort({
        createdAt: -1,
      })
      .limit(10);

    return res
      .status(200)
      .json(new ApiResponse(200, "RelatedNews data fetch", relatedNews));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export {
  LatestpublicNews,
  getAllnewsByCategory,
  abc,
  categoryList,
  getNewsBySlug,
  RelatedNews,
};
