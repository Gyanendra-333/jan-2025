import type { CookieOptions, Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiResponse } from "../utlis/ApiResponse";
import { UserModel } from "../model/user.model";
import { ApiError } from "../utlis/ApiError";
import type { IUser } from "../types/mongooseTypes";
import sendMailTemplate from "../utlis/sendOTP";
import type { reciverDetail, templateDetailType } from "../types/MailTypes";
import { generateAccessAndRefreshToken, generateOTP } from "../helper";
import config from "../config/config";
import jwt from "jsonwebtoken";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface EmailOTP {
  OTP: number | undefined;
  expire: number | undefined;
}

const EmailToOTP = new Map<string, EmailOTP>();

const cookieOptions: CookieOptions = {
  httpOnly: true, // Prevents client-side JavaScript from accessing the cookie
  secure: true, // Ensures the cookie is sent over HTTPS
  maxAge: 7 * 24 * 60 * 60 * 1000, // Cookie expires in 7 day (milliseconds)
  path: "/",
};

const adminSignUp = asyncHandler(async (req: Request, res: Response) => {
  const { verifycode } = req.query;
  const { name, email, password } = req.body as {
    name: string;
    email: string;
    password: string;
  };

  if ([name, email, password].some((item) => item.trim() === "")) {
    return res
      .status(400)
      .json(new ApiError(400, "All fields are required", req));
  }

  try {
    const existingUser = await UserModel.findOne({ email });

    if (existingUser)
      return res.status(400).json(new ApiError(400, "User already exist", req));

    const isAdmin = (verifycode as string) === "123" ? "admin" : "user";

    const user = await UserModel.create({
      name,
      email,
      password,
      role: isAdmin,
    });

    if (!user) {
      return res
        .status(500)
        .json(new ApiError(500, "Failed to register user", req));
    }

    const newUser: Partial<IUser> = user.toObject();
    delete newUser.password;
    delete newUser.refreshToken;

    const { OTP, min, expire } = generateOTP();
    EmailToOTP.set(user.email, { OTP, expire });

    const templateDetail: templateDetailType = {
      url: "SendEmailOTP.ejs",
      title: "Verify Your Account",
      userName: user.name,
      OTP: OTP,
      min,
    };
    const sendMailUser: reciverDetail = {
      email: user.email,
      Sub: "Verify your account",
    };

    const isEmailSend = await sendMailTemplate(sendMailUser, templateDetail);

    if (!isEmailSend) {
      await sendMailTemplate(sendMailUser, templateDetail);
    }

    res
      .status(200)
      .json(new ApiResponse(200, "User register successfully", newUser));

    return res.redirect(`${config.SERVER_URL}/login`);
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const adminLogin = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body as { email: string; password: string };

  if (!email?.trim() || !password?.trim())
    return res
      .status(400)
      .json(new ApiError(400, "All fields are required", req));

  const user = await UserModel.findOne({ email });
  if (!user) {
    return res.status(400).json(new ApiError(400, "User do not exist", req));
  }

  const isValidPassword = await user.isPasswordCorrect(password);

  if (!isValidPassword) {
    return res.status(400).json(new ApiError(400, "Invalid Credential", req));
  }
  if (!user.isEmailVerified) {
    return res
      .status(400)
      .json(new ApiError(400, "Please verify your account first", req));
  }
  const { accessToken, refreshToken } = (await generateAccessAndRefreshToken(
    user._id
  )) as { accessToken: string; refreshToken: string };

  const loggedInUser: Partial<IUser> = user.toObject();
  delete loggedInUser.password;
  delete loggedInUser.refreshToken;

  return res
    .status(200)
    .cookie("accessToken", accessToken, cookieOptions)
    .cookie("refreshToken", refreshToken, cookieOptions)
    .json(
      new ApiResponse(200, "Login Successfully", {
        ...loggedInUser,
        refreshToken,
        accessToken,
      })
    );
});

const Adminlogout = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { _id } = req.user as IUser;
    await UserModel.findByIdAndUpdate(
      _id,
      { $unset: { refreshToken: 1 } },
      { new: true }
    );
    const option: CookieOptions = {
      httpOnly: true,
      secure: true,
    };
    return res
      .status(200)
      .clearCookie("accessToken", option)
      .clearCookie("refreshToken", option)
      .json(new ApiResponse(200, "Logout Successfully", undefined));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const verifyOTP = asyncHandler(async (req: Request, res: Response) => {
  const { email, code } = req.body as { email: string; code: number };
  if (String(code).length < 4) {
    return res.status(400).json(new ApiError(500, "Invalid OTP", req));
  }
  if (!email) {
    return res.status(400).json(new ApiError(500, "Invalid request", req));
  }
  try {
    const user = await UserModel.findOne({ email });
    if (!user) {
      return res.status(400).json(new ApiError(400, "User do not exist", req));
    }

    const { OTP, expire } = EmailToOTP.get(user.email) as EmailOTP;
    if (
      (typeof code === "number" && code !== OTP) ||
      (typeof expire === "number" && expire < Date.now())
    ) {
      return res
        .status(400)
        .json(new ApiError(400, "Invalid OTP or the OTP expire", req));
    }
    user.isEmailVerified = true;
    await user.save({ validateBeforeSave: false });
    EmailToOTP.set(user.email, { expire: undefined, OTP: undefined });
    return res
      .status(200)
      .json(new ApiResponse(200, "Email verify successfully", undefined));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const forgetPassword = asyncHandler(async (req, res) => {
  const { email } = req.body as { email: string };
  if (!email || !emailRegex.test(email)) {
    return res.status(400).json(new ApiError(400, "Invalid Email", req));
  }
  try {
    const user = await UserModel.findOne({ email });
    if (!user) {
      return res.status(400).json(new ApiError(400, "User do not exist", req));
    }
    const { OTP, expire, min } = generateOTP();

    EmailToOTP.set(user.email, { OTP, expire });

    const sendMailUser = { email: user.email, Sub: "Verify your account" };

    const templateDetail: templateDetailType = {
      url: "SendEmailOTP.ejs",
      title: "Verify Your Account",
      userName: user.name,
      OTP: OTP,
      min,
    };
    const isEmailSend = await sendMailTemplate(sendMailUser, templateDetail);
    if (!isEmailSend) {
      return res
        .status(500)
        .json(new ApiError(500, "failed to send mail", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "OTP send successfully", undefined));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const changePassword = asyncHandler(async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body as {
    currentPassword: string;
    newPassword: string;
  };
  const user = req.user as IUser;
  try {
    const isPasswordCorrect = await user.isPasswordCorrect(currentPassword);
    if (!isPasswordCorrect) {
      return res.status(400).json(new ApiError(400, "Incorrect Password", req));
    }
    user.password = newPassword;
    await user.save(); //idhar nhi lgega { validateBeforeSave: false }
    return res
      .status(200)
      .json(new ApiResponse(200, "Password change successfuly", undefined));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const refreshAccessToken = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { refreshToken: oldRefreshToken } = req.body as {
      refreshToken: string;
    };
    const incomingToken: string | undefined =
      (req.cookies.refreshToken as string) || oldRefreshToken;

    if (!incomingToken) {
      return res
        .status(400)
        .json(new ApiError(400, "unauthorized request", req));
    }

    const decodedToken = jwt.verify(
      incomingToken,
      config.REFRESH_TOKEN_SECRET
    ) as { id: string };

    if (!decodedToken) {
      return res
        .status(400)
        .json(new ApiError(400, "unauthorized request", req));
    }
    const user = await UserModel.findById(decodedToken.id);
    if (!user) {
      return res
        .status(401)
        .json(new ApiError(401, "Invalid Access Token", req));
    }
    if (incomingToken !== user.refreshToken) {
      return res
        .status(401)
        .json(new ApiError(401, "Invalid Access Token", req));
    }
    const { accessToken, refreshToken } = (await generateAccessAndRefreshToken(
      user._id
    )) as {
      refreshToken: string;
      accessToken: string;
    };
    return res
      .status(200)
      .cookie("accessToken", accessToken, cookieOptions)
      .cookie("refreshToken", refreshToken, cookieOptions)
      .json(
        new ApiResponse(200, "Token refreshed", { accessToken, refreshToken })
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export {
  adminSignUp,
  adminLogin,
  Adminlogout,
  verifyOTP,
  forgetPassword,
  changePassword,
  refreshAccessToken,
};
