/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { type Request, type Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiError } from "../utlis/ApiError";
import { ApiResponse } from "../utlis/ApiResponse";
import { NewsModel } from "../model/news.model";
import {
  DeleteBucketFile,
  UploadBuckethandler,
} from "../utlis/CloudBucketHandler";
import { Types } from "mongoose";

const createNews = asyncHandler(async (req: Request, res: Response) => {
  const data = req.body as {
    title: string;
    slug: string;
    description: string;
    metaDesciption: string;
    alt: string;
    type: string;
    status: number;
    categoryId: string;
    subCategoryId: string | null;
    publisherId: string;
    anchorId: string | null;
  };

  try {
    const file = req.file;

    if (!file) {
      return res.status(400).json(new ApiError(400, "Image is required", req));
    }

    const img = await UploadBuckethandler(file, "news");

    const Image = {
      ImageID: img?.uploadID as string,
      ImageURL: img?.URL,
    };
    if (!data.subCategoryId || !data.subCategoryId?.trim()) {
      data.subCategoryId = null;
    }
    if (!data.anchorId || !data.anchorId?.trim()) {
      data.subCategoryId = null;
    }

    const createNews = await NewsModel.create({ ...data, Image });

    if (!createNews) {
      return res.status(400).json(new ApiError(400, "News not added", req));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "News created successfully", createNews));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// update news
const UpdateNews = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const file = req.file;

  const data = req.body as {
    title: string;
    slug: string;
    description: string;
    metaDesciption: string;
    alt: string;
    type: string;
    status: number;
    categoryId: string;
    subCategoryId: string | null;
    publisherId: string;
    anchorId: string | null;
  };

  if (!id) {
    return res.status(400).json(new ApiError(400, "News not Updated", req));
  }
  try {
    const news = await NewsModel.findById(id);

    if (!news) {
      return res
        .status(400)
        .json(new ApiError(400, "Unbale to update News", req));
    }
    if (
      !data.subCategoryId ||
      !data.subCategoryId?.trim() ||
      data.subCategoryId === "null"
    ) {
      data.subCategoryId = null;
    }
    if (
      !data.anchorId ||
      !data.anchorId?.trim() ||
      data.subCategoryId === "null"
    ) {
      data.subCategoryId = null;
    }

    if (file) {
      await DeleteBucketFile(news.Image.ImageID);
      const img = await UploadBuckethandler(file, "news");

      const Image = {
        ImageID: img?.uploadID as string,
        ImageURL: img?.URL,
      };
      const UpdatedNews = await NewsModel.findByIdAndUpdate(
        { _id: id },
        { ...data, Image },
        { new: true }
      );
      return res
        .status(200)
        .json(new ApiResponse(200, "News Updated Successfully", UpdatedNews));
    }

    const UpdatedNews = await NewsModel.findByIdAndUpdate(
      { _id: id },
      { ...data },
      { new: true }
    );

    return res
      .status(200)
      .json(new ApiResponse(200, "News Updated Successfully", UpdatedNews));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// delete new
const deleteNews = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!id) {
    return res.status(400).json(new ApiError(400, "New not delete", req));
  }

  try {
    const news = await NewsModel.findById(id);

    if (!news) {
      return res.status(400).json(new ApiError(400, "News Not found", req));
    }
    const deletedImage = await DeleteBucketFile(news.Image.ImageID);

    if (!deletedImage) {
      return res
        .status(400)
        .json(new ApiError(400, "Failed to delete Image", req));
    }
    const deletedNews = await NewsModel.findByIdAndDelete(id);

    if (!deletedNews) {
      return res.status(400).json(new ApiError(400, "News not delete", req));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "News deleted sucessfully", deleteNews));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// get News
const getNews = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { query } = req;
    const page = Number(query?.page) || 1;
    const limit = Number(query?.limit) || 5;
    const newPage = limit * (page - 1);
    const shownews = await NewsModel.aggregate([
      {
        $lookup: {
          from: "categories",
          foreignField: "_id",
          localField: "categoryId",
          as: "category",
        },
      },
      {
        $lookup: {
          from: "subcategories",
          foreignField: "_id",
          localField: "subCategoryId",
          as: "subcategory",
        },
      },
      {
        $lookup: {
          from: "publishers",
          foreignField: "_id",
          localField: "publisherId",
          as: "publisher",
        },
      },
      {
        $lookup: {
          from: "anchors",
          foreignField: "_id",
          localField: "anchorId",
          as: "anchor",
        },
      },
      {
        $facet: {
          data: [
            {
              $project: {
                title: 1,
                slug: 1,
                Image: 1,
                status: 1,
                views: 1,
                createdAt: 1,
                updatedAt: 1,
                category: { $arrayElemAt: ["$category.name", 0] },
                subcategory: { $arrayElemAt: ["$subcategory.name", 0] },
                publisher: { $arrayElemAt: ["$publisher.name", 0] },
                anchor: { $arrayElemAt: ["$anchor.name", 0] },
              },
            },
            { $skip: newPage },
            { $limit: limit },
          ],
          totalCount: [{ $count: "count" }],
        },
      },
    ]).sort("-1");

    const count = shownews[0]?.totalCount[0]?.count;
    const data = shownews[0]?.data;

    if (!shownews) {
      return res
        .status(400)
        .json(new ApiError(400, "News Data not found", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "News Data fetched", { count, data }));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

//get news by ID

const getNewsByID = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { id } = req.params as { id: string };
    const objectId = new Types.ObjectId(id);

    const getNews = await NewsModel.aggregate([
      { $match: { _id: objectId } },
      {
        $lookup: {
          from: "categories",
          foreignField: "_id",
          localField: "categoryId",
          as: "category",
        },
      },
      {
        $lookup: {
          from: "subcategories",
          foreignField: "_id",
          localField: "subCategoryId",
          as: "subcategory",
        },
      },
      {
        $lookup: {
          from: "publishers",
          foreignField: "_id",
          localField: "publisherId",
          as: "publisher",
        },
      },
      {
        $lookup: {
          from: "anchors",
          foreignField: "_id",
          localField: "anchorId",
          as: "anchor",
        },
      },
      {
        $project: {
          title: 1,
          slug: 1,
          Image: 1,
          status: 1,
          description: 1,
          metaDescription: 1,
          videoURL: 1,
          alt: 1,
          tags: 1,
          views: 1,
          createdAt: 1,
          updatedAt: 1,
          categoryId: 1,
          subCategoryId: 1,
          publisherId: 1,
          anchorId: 1,
          category: { $arrayElemAt: ["$category.name", 0] },
          subcategory: { $arrayElemAt: ["$subcategory.name", 0] },
          publisher: { $arrayElemAt: ["$publisher.name", 0] },
          anchor: { $arrayElemAt: ["$anchor.name", 0] },
        },
      },
    ]);
    if (!getNews[0]) {
      return res
        .status(400)
        .json(new ApiError(400, "Unbale to fetch news", req));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "News data fetched successfully", getNews[0]));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export { createNews, UpdateNews, deleteNews, getNews, getNewsByID };
