import type { Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiError } from "../utlis/ApiError";
import { ContactModel } from "../model/contact.model";
import { ApiResponse } from "../utlis/ApiResponse";

// create Contact

const createContact = asyncHandler(async (req: Request, res: Response) => {
  const data = req.body as {
    fullName: string;
    email: string;
    phone: number;
    message: string;
  };

  try {
    const contact = await ContactModel.create(data);
    if (!contact) {
      return res
        .status(400)
        .json(new ApiError(400, "contact not created", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "message sent successfully", contact));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// Get admin contact details
const getConatctDetails = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { query } = req;
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 10;
    const newPage = limit * (page - 1);

    const showContactDetails = await ContactModel.aggregate([
      {
        $facet: {
          data: [
            {
              $project: {
                fullName: 1,
                email: 1,
                phone: 1,
                message: 1,
              },
            },
            { $skip: newPage },
            { $limit: limit },
            { $sort: { createdAt: -1 } },
          ],
          totalCount: [{ $count: "count" }],
        },
      },
    ]);

    if (showContactDetails.length === 0) {
      return res
        .status(200)
        .json(new ApiResponse(200, "conatct details feched successfully", []));
    }
    return res
      .status(200)
      .json(
        new ApiResponse(
          200,
          "conatct details feched successfully",
          showContactDetails[0]
        )
      );
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

export { createContact, getConatctDetails };
