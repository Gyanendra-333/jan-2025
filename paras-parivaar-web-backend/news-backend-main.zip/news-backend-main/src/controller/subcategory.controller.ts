/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import type { Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiError } from "../utlis/ApiError";
import { SubCategoryModel } from "../model/subCategory.model";
import { ApiResponse } from "../utlis/ApiResponse";
import mongoose from "mongoose";

const createSubcategory = asyncHandler(async (req: Request, res: Response) => {
  const data = req.body as {
    categoryId: string;
    newsId: string;
    name: string;
  };
  try {
    const createdSubcategory = await SubCategoryModel.create(data);

    if (!createdSubcategory) {
      return res
        .status(400)
        .json(new ApiError(400, "Subcategory not created", req));
    }

    return res
      .status(200)
      .json(
        new ApiResponse(
          200,
          "Subcategory created successfully",
          createdSubcategory
        )
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// update SubCAtegory
const updateSubCategory = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const data = req.body as {
    categoryId: string;
    newsId: string;
    name: string;
  };

  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Subcategory updated failed", req));
  }

  try {
    const updatedSubCategory = await SubCategoryModel.findByIdAndUpdate(
      { _id: id },
      { ...data },
      { new: true }
    );

    if (!updatedSubCategory) {
      return res
        .status(400)
        .json(new ApiError(400, "Subcategory not Updated", req));
    }

    return res
      .status(200)
      .json(
        new ApiResponse(
          200,
          "SubCategory Updated Successfully",
          updatedSubCategory
        )
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

//  delete subCategory

const deleteSubCategory = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Subcategory not deleted", req));
  }
  try {
    const subCategorydeleted = await SubCategoryModel.findByIdAndDelete({
      _id: id,
    });
    if (!subCategorydeleted) {
      return res
        .status(400)
        .json(new ApiError(400, "SubCategory deleted failed", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "SubCategory deleted successfully", ""));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// get Subcategory list

const getSubCategoryList = asyncHandler(async (req: Request, res: Response) => {
  try {
    const { query } = req;
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 2;
    const newPage = limit * (page - 1);


    const showSubCategory = await SubCategoryModel.aggregate([
      {
        $lookup: {
          localField: "categoryId",
          foreignField: "_id",
          from: "categories",
          as: "category",
        },
      },
      {
        $unwind: {
          path: "$category",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $facet: {
          data: [
            {
              $project: {
                _id: 1,
                name: 1,
                categoryId: 1,
                createdAt: 1,
                updatedAt: 1,
                __v: 1,
                category: {
                  name: "$category.name",
                },
              },
            },
            { $skip: newPage },
            { $limit: limit },
          ],
          totalCount: [{ $count: "count" }],
        },
      },
    ]).sort("-1");

    const count = (showSubCategory?.[0]?.totalCount[0]?.count || 0) as number;
    const data = showSubCategory[0].data;

    if (!count) {
      return res
        .status(200)
        .json(new ApiResponse(200, "SubCategory fetched Successfully", []));
    }

    return res.status(200).json(
      new ApiResponse(200, "SubCategory fetched Successfully", {
        data,
        count,
      })
    );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// get subcategory
const getSubCategory = asyncHandler(async (req: Request, res: Response) => {
  const { categoryId } = req.params as { categoryId: string };

  if (!mongoose.Types.ObjectId.isValid(categoryId)) {
    return res.status(400).json(new ApiError(400, "Invalid Category Id", req));
  }

  try {
    const showSubCategory = await SubCategoryModel.find({ categoryId });

    if (showSubCategory.length === 0) {
      return res
        .status(400)
        .json(new ApiError(400, "SubCategory not fetched", req));
    }

    return res
      .status(200)
      .json(
        new ApiResponse(
          200,
          "SubCategory fetched Successfully",
          showSubCategory
        )
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export {
  createSubcategory,
  updateSubCategory,
  deleteSubCategory,
  getSubCategoryList,
  getSubCategory,
};
