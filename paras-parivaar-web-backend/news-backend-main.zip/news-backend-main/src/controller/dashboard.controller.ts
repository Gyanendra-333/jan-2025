import type { Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiResponse } from "../utlis/ApiResponse";
import { ApiError } from "../utlis/ApiError";
import { NewsModel } from "../model/news.model";
import { PublisherModel } from "../model/publisher.model";
import { AnchorModel } from "../model/anchor.model";

const DashboardCards = asyncHandler(async (req: Request, res: Response) => {
  try {
    const [newsCount, publisherCount, anchorCount, viewsAggregation] =
      await Promise.all([
        NewsModel.countDocuments(),
        PublisherModel.countDocuments(),
        AnchorModel.countDocuments(),
        NewsModel.aggregate([
          {
            $group: {
              _id: null,
              totalViews: { $sum: "$views" },
            },
          },
        ]),
      ]);

    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    const totalViews = (viewsAggregation?.[0]?.totalViews as number) ?? 0;

    const result = {
      totalNews: newsCount,
      totalPublishers: publisherCount,
      totalAnchors: anchorCount,
      totalViews: totalViews,
    };

    return res
      .status(200)
      .json(new ApiResponse(200, "Dashboard card Data", result));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const popularNews = asyncHandler(async (req: Request, res: Response) => {
  try {
    const data = await NewsModel.aggregate([
      {
        $lookup: {
          from: "categories",
          localField: "categoryId",
          foreignField: "_id",
          as: "category",
          pipeline: [
            {
              $project: {
                name: 1,
              },
            },
          ],
        },
      },
      { $unwind: "$category" },
      {
        $lookup: {
          from: "publishers",
          localField: "publisherId",
          foreignField: "_id",
          as: "publisher",
        },
      },
      { $unwind: "$publisher" },
      {
        $sort: { views: -1 },
      },
      {
        $limit: 5,
      },
    ]);

    return res
      .status(200)
      .json(new ApiResponse(200, "Dashboard card Data", data));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export { DashboardCards, popularNews };
