import type { Request, Response } from "express";
import { AnchorModel } from "../model/anchor.model";
import { ApiError } from "../utlis/ApiError";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiResponse } from "../utlis/ApiResponse";

// create anchor
const createAcnhor = asyncHandler(async (req: Request, res: Response) => {
  const { name } = req.body as { name: string };

  try {
    const anchor = await AnchorModel.create({ name });

    if (!anchor) {
      return res.status(400).json(new ApiError(400, "Anchor not created", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Anchor created successfully", anchor));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// update anchor

const updateAnchor = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  const { name } = req.body as { name: string };

  if (!id) {
    return res.status(400).json(new ApiError(400, "Anchor not updated", req));
  }

  try {
    const updatedAnchor = await AnchorModel.findByIdAndUpdate(
      { _id: id },
      { name: name },
      { new: true }
    );

    if (!updatedAnchor) {
      return res.status(400).json(new ApiError(400, "Anchor update failed"));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "Anchor updated successfully", updatedAnchor));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// Anchor delete

const deleteAnchor = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json(new ApiError(400, "Anchor not deleted", req));
  }

  try {
    const deletedAnchor = await AnchorModel.findByIdAndDelete({ _id: id });

    if (!deletedAnchor) {
      return res.status(400).json(new ApiError(400, "Anchor not deleted", req));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Anchor deleted successfully", null));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

// Anchor get

const getAnchor = asyncHandler(async (req: Request, res: Response) => {
  try {
    const showAnchor = await AnchorModel.find();

    if (showAnchor.length === 0) {
      return res.status(400).json(new ApiError(400, "Anchor not fetched", req));
    }

    return res
      .status(200)
      .json(new ApiResponse(200, "Anchor feched successfully", showAnchor));
  } catch (error) {
    return res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
});

export { createAcnhor, updateAnchor, deleteAnchor, getAnchor };
