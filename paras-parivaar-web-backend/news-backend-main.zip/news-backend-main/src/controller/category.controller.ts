import { CategoryModel } from "../model/category.model";
import { SubCategoryModel } from "../model/subCategory.model";
import { ApiError } from "../utlis/ApiError";
import { ApiResponse } from "../utlis/ApiResponse";
import { asyncHandler } from "../utlis/asyncHandler";
import type { Request, Response } from "express";

// create category
const createCategory = asyncHandler(async (req: Request, res: Response) => {
  const { name } = req.body as { name: string };

  try {
    const createdCategory = await CategoryModel.create({ name });

    if (!createdCategory) {
      return res
        .status(400)
        .json(new ApiError(400, "Category created failed", req));
    }
    return res
      .status(200)
      .json(
        new ApiResponse(200, "Category created sucessfully", createdCategory)
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// update cateogry

const updatecategory = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { name } = req.body as { name: string };
  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Category updated failed", req));
  }
  if (!name) {
    return res
      .status(400)
      .json(new ApiError(400, "Name field is required", req));
  }

  try {
    const updatedCategory = await CategoryModel.findByIdAndUpdate(
      { _id: id },
      { name: name },
      { new: true }
    );

    if (!updatedCategory) {
      return res
        .status(400)
        .json(new ApiError(400, "Category updated failed", req));
    }

    return res
      .status(200)
      .json(
        new ApiResponse(200, "Category updated sucessfully", updatedCategory)
      );
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

// delete category

const deleteCategory = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!id) {
    return res
      .status(400)
      .json(new ApiError(400, "Category updated failed", req));
  }

  try {
    const children_delete = await SubCategoryModel.deleteMany({
      categoryId: id,
    });

    if (children_delete.acknowledged) {
      const deleted = await CategoryModel.findByIdAndDelete({ _id: id });
      if (!deleted) {
        return res
          .status(400)
          .json(new ApiError(400, "Category delete failed", req));
      }
      return res
        .status(200)
        .json(new ApiResponse(200, "Category delete sucessfully", ""));
    }

    return res
      .status(400)
      .json(new ApiError(400, "Category delete failed", req));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

const getCategory = asyncHandler(async (req: Request, res: Response) => {
  try {
    const showCategory = await CategoryModel.find();

    if (showCategory.length === 0) {
      return res
        .status(200)
        .json(new ApiResponse(200, "Category fetched sucessfully", []));
    }
    return res
      .status(200)
      .json(new ApiResponse(200, "Category fetched sucessfully", showCategory));
  } catch (error) {
    return res
      .status(500)
      .json(new ApiError(500, "Something went wrong", req, [error]));
  }
});

export { createCategory, updatecategory, deleteCategory, getCategory };
