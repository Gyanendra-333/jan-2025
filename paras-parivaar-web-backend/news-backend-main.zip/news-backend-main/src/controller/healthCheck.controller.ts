import { type Request, type Response } from "express";
import SystemHelth from "../utlis/healthCheck";
import { ApiResponse } from "../utlis/ApiResponse";
import { ApiError } from "../utlis/ApiError";

const healthCheck = (req: Request, res: Response) => {
  try {
    const health = {
      application: SystemHelth.getApplicationHealth(),
      system: SystemHelth.getSystemHealth(),
      timestamp: Date.now(),
    };
    if (!health) {
      res.status(400).json(new ApiError(400, "Health Check Failed", req));
      return;
    }
    res.status(200).json(new ApiResponse(200, "Health Report", health));
  } catch (error) {
    res
      .status(500)
      .json(
        new ApiError(500, "Something went wrong", null, [JSON.stringify(error)])
      );
  }
};

export default healthCheck;
