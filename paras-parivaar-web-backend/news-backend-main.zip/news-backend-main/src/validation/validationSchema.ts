import mongoose from "mongoose";
import { z as zod } from "zod";

const AdminSchema = zod.object({
  name: zod.string().min(2).max(15).trim(),
  email: zod.string().email().trim(),
  password: zod.string().min(8).trim(),
});

const NewsSchema = zod.object({
  title: zod.string().min(10).max(100),
  slug: zod.string().min(5).regex(/^\S+$/, {
    message: "The string must not contain any spaces",
  }),
  description: zod.string().min(200),
  metaDescription: zod.string().min(10).max(200),
  videoURL: zod.string(),
  alt: zod.string().min(3).max(50),
  tags: zod.string(),
  categoryId: zod
    .string()
    .refine((val) => mongoose.Types.ObjectId.isValid(val), {
      message: "Invalid ID",
    }),
  subCategoryId: zod.string().optional(),
  publisherId: zod
    .string()
    .refine((val) => mongoose.Types.ObjectId.isValid(val), {
      message: "Invalid ID",
    }),
  anchorId: zod.string().optional(),
});

const CategorySchema = zod.object({
  name: zod.string().min(3).max(20),
  newsId: zod
    .string()
    .refine((val) => mongoose.Types.ObjectId.isValid(val), {
      message: "Invalid ID",
    })
    .optional(),
});
const SubcategorySchema = zod.object({
  name: zod.string().min(3).max(20),
  categoryId: zod
    .string()
    .refine((val) => mongoose.Types.ObjectId.isValid(val), {
      message: "Invalid ID",
    }),
  newsId: zod
    .string()
    .refine((val) => mongoose.Types.ObjectId.isValid(val), {
      message: "Invalid ID",
    })
    .optional(),
});

const PublisherSchema = zod.object({
  name: zod.string().min(3).max(20),
});

const AnchorSchema = zod.object({
  name: zod.string().min(3).max(20),
});

const LangSchema = zod.object({
  name: zod.string().min(3).max(20),
});

const ConatctSchema = zod.object({
  fullName: zod.string().trim(),
  email: zod.string().email().trim(),
  phone: zod.number(),
  message: zod.string().trim(),
});

export {
  AdminSchema,
  NewsSchema,
  CategorySchema,
  SubcategorySchema,
  PublisherSchema,
  AnchorSchema,
  LangSchema,
  ConatctSchema,
};
