import type { Request, Response, NextFunction } from "express";
import { ZodType, ZodError } from "zod";
import { ApiError } from "../utlis/ApiError";

class Validator<T> {
  private schema: ZodType<T>;

  constructor(schema: ZodType<T>) {
    this.schema = schema;
  }

  validate = (req: Request, res: Response, next: NextFunction): void => {
    try {
      this.schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errorDetails = error?.errors?.map((issue) => ({
          path: issue?.path.join("."),
          message: issue?.message,
        }));
        res
          .status(400)
          .json(new ApiError(400, "Validation failed", req, errorDetails));
      } else {
        res
          .status(500)
          .json(new ApiError(500, "Something went wrong", req, [error]));
      }
    }
  };
}

export { Validator };
