import DotenvFlow from "dotenv-flow";
DotenvFlow.config();

export default {
  // #General
  ENV: process.env.ENV as string,
  PORT: process.env.PORT,
  SERVER_URL: process.env.SERVER_URL as string,

  // #DataBase
  DB_NAME: process.env.DB_NAME as string,
  MONGODB_URL: process.env.MONGODB_URL as string,
  MIGRATE_MONGO_URI: process.env.MIGRATE_MONGO_URI as string,

  // JWT
  ACCESS_TOKEN_EXPIRY: process.env.ACCESS_TOKEN_EXPIRY as string,
  ACCESS_TOKEN_SECRET: process.env.ACCESS_TOKEN_SECRET as string,
  REFRESH_TOKEN_EXPIRY: process.env.REFRESH_TOKEN_EXPIRY as string,
  REFRESH_TOKEN_SECRET: process.env.REFRESH_TOKEN_SECRET as string,

  //Bucket
  BUCKET_NAME: process.env.BUCKET_NAME as string,

  //Nodemailer
  Auth_MAIL: process.env.Auth_MAIL as string,
  Auth_PASS: process.env.Auth_PASS as string,

  //rateLimiter
  points: process.env.POINTS as string,
};
