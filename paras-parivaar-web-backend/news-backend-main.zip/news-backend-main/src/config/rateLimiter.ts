import type { Connection } from "mongoose";
import { RateLimiterMongo } from "rate-limiter-flexible";
import config from "./config";

export let rateLimiterMongo: null | RateLimiterMongo = null;

export const initRateLimiter = (mongooseConnection: Connection) => {
  rateLimiterMongo = new RateLimiterMongo({
    storeClient: mongooseConnection,
    points: Number(config?.points),
    duration: 60,
  });
};
