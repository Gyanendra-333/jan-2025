import mongoose, { Error } from "mongoose";
import config from "./config";

export const connectDB = async () => {
  try {
    const connection = await mongoose.connect(`${config.MONGODB_URL}`, {
      dbName: config.DB_NAME ,
    });

    return connection.connection;
  } catch (error: unknown) {
    throw new Error(JSON.stringify(error));
  }
};

//mongoose.connection and connection.connection are same
