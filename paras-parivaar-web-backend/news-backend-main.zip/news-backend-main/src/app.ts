import express, { type Application } from "express";
import cookieParser from "cookie-parser";
import cors, { type CorsOptions } from "cors";
import indexRouter from "./router/index";
import helmet from "helmet";
import globalErrorHandler from "./middleware/globalErrorHandler";

const app: Application = express();

const corsOptions: CorsOptions = {
  origin: ["http://localhost:5173", `http://localhost:3000`],
  credentials: true,
};

//Middlewares

app.use(helmet());
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(cookieParser());
app.use(express.static("public"));

//Routes
app.use(
  "/api/v1",
  (req, res, next) => {
    setTimeout(() => {}, 2000);
    next();
  },
  indexRouter
);

app.use("/*", globalErrorHandler);

export default app;
