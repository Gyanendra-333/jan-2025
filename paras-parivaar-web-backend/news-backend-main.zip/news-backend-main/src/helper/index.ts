import { UserModel } from "../model/user.model";
import { ApiError } from "../utlis/ApiError";

const generateOTP = () => {
  const OTP = Math.floor(1000 + Math.random() * 9000);
  const min = 5;
  const expire = Date.now() + 1000 * 60 * min;

  return { OTP, min, expire };
};
const generateAccessAndRefreshToken = async (userid: string) => {
  try {
    const user = await UserModel.findById(userid);
    if (!user) {
      return { accessToken: "", refreshToken: "" };
    }
    const accessToken = user.generateAccessToken();
    const refreshToken = user.generateRefreshToken();

    user.refreshToken = refreshToken;
    await user.save({ validateBeforeSave: false });

   

    return { accessToken, refreshToken };
  } catch (error) {
    throw new ApiError(500, "something went wrong", null, [error]);
  }
};

export { generateOTP, generateAccessAndRefreshToken };
