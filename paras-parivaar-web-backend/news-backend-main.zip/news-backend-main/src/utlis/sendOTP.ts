import fs from "fs";
import path from "path";
import ejs from "ejs";
import { fileURLToPath } from "url";
import config from "../config/config";
import mailer from "nodemailer";
import type { MailOptions } from "nodemailer/lib/sendmail-transport";
import type { reciverDetail, templateDetailType } from "../types/MailTypes";
import type SMTPTransport from "nodemailer/lib/smtp-transport";
import logger from "./logger";

async function SendMailTemplate(
  item: reciverDetail,
  template: templateDetailType
) {
  try {
    const mailTransporter: mailer.Transporter<
      SMTPTransport.SentMessageInfo,
      SMTPTransport.Options
    > = mailer.createTransport({
      service: "gmail",
      secure: true,
      auth: {
        user: config.Auth_MAIL,
        pass: config.Auth_PASS,
      },
    });

    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);

    const templatePath = path.join(__dirname, "templates", template.url);

    const templatefile = fs.readFileSync(templatePath, "utf-8");

    const html = ejs.render(templatefile, template);

    const mailingdetail: MailOptions = {
      from: process.env.Auth_mail,
      to: item.email,
      subject: item.Sub,
      html,
    };
    const isMailSend = await mailTransporter.sendMail(mailingdetail);

    if (!isMailSend) {
      logger.error("Falied to send mail", isMailSend);
      return false;
    }
    return true;
  } catch (error) {
    if (error instanceof Error) {
      return false;
    } else {
      return false;
    }
  }
}

export default SendMailTemplate;
