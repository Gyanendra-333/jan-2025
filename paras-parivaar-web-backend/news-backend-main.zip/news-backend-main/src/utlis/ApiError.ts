import type { Request } from "express";
import config from "../config/config";
import { EApplicationEnviroment } from "../constant/application";
import logger from "./logger";

/* eslint-disable @typescript-eslint/no-explicit-any */
class ApiError extends Error {
  public statusCode: number;
  public errors: any[];

  public request: object | null;

  constructor(
    statusCode: number = 500,
    message: string = "Something went wrong",
    req: Request | null = null,
    errors: any[] = [],
    stack: string = ""
  ) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors;
    this.request = req
      ? {
          ip: req.ip,
          method: req.method,
          url: req.originalUrl,
        }
      : null;
    //Production Env check

    if (config.ENV === (EApplicationEnviroment.PRODUCTION as string) && req) {
      this.request = null;
    }
    if (stack) {
      this.stack = stack;
    } else {
      Error.captureStackTrace(this, this.constructor);
    }
    logger.error("API Error", {
      message: this.message,
      statusCode: this.statusCode,
      errors: this.errors,
      ...(this.request ? { request: this.request } : {}),
      // Optionally log the stack trace only in non-production environments.
      ...(config.ENV !== (EApplicationEnviroment.PRODUCTION as string)
        ? { stack: this.stack }
        : {}),
    });
  }

  //
  public toJSON() {
    return {
      statusCode: this.statusCode,
      message: this.message,
      errors: this.errors,
      // Include request details only if they're available (and allowed)
      ...(this.request ? { request: this.request } : {}),
      // Optionally include the stack trace in non-production environments
      ...(config.ENV !== EApplicationEnviroment.PRODUCTION as string
        ? { stack: this.stack }
        : {}),
    };
  }
}

export { ApiError };
