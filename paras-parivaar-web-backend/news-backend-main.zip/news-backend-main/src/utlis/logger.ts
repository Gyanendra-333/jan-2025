import { createLogger, format, transports } from "winston";
import type {
  ConsoleTransportInstance,
  FileTransportInstance,
} from "winston/lib/winston/transports";
import util from "util";
import type { TransformableInfo } from "logform";
import config from "../config/config";
import { EApplicationEnviroment } from "../constant/application";
import path from "path";
import * as sourceMapSupport from "source-map-support";
import { blue, green, magenta, red, yellow } from "colorette";
import "winston-mongodb";
import type { MongoDBTransportInstance } from "winston-mongodb";

//Linking Trace Support
sourceMapSupport.install();

const colorizeLevel = (level: string) => {
  switch (level) {
    case "ERROR":
      return red(level);
    case "INFO":
      return blue(level);
    case "WARN":
      return yellow(level);

    default:
      return level;
  }
};

const consoleLogFormat = format.printf((info: TransformableInfo) => {
  const { level, message, timestamp, meta = {} } = info;

  const customLevel = colorizeLevel(level.toUpperCase());
  const customTimeStamp = green(timestamp as string);
  const customMessage = JSON.stringify(message);
  const customMeta = util.inspect(meta, {
    showHidden: false,
    depth: null,
    colors: true,
  });
  const customLog = `${customLevel} [${customTimeStamp}]\nmessage: ${customMessage}\n${magenta("META")} ${customMeta}\n`;
  return customLog;
});

const consoleTransport = (): Array<ConsoleTransportInstance> => {
  if (config.ENV === EApplicationEnviroment.DEVELOPMENT) {
    return [
      new transports.Console({
        level: "info",
        format: format.combine(format.timestamp(), consoleLogFormat),
      }),
    ];
  }
  return [];
};

const fileLogFormat = format.printf((info: TransformableInfo) => {
  const { level, message, timestamp, meta = {} } = info;
  const logMeta: Record<string, unknown> = {};

  const metaObj = typeof meta === "object" && meta !== null ? meta : {};
  for (const [key, value] of Object.entries(metaObj)) {
    if (value instanceof Error) {
      logMeta[key] = {
        name: value.name,
        message: value.message,
        trace: value.stack || "",
      };
    } else {
      logMeta[key] = value;
    }
  }
  const logData = {
    level: level.toUpperCase(),
    message,
    timestamp,
    meta: logMeta,
  };
  return JSON.stringify(logData, null, 4);
});
const infoFileTransport = (): FileTransportInstance => {
  return new transports.File({
    level: "info",
    format: format.combine(format.timestamp(), fileLogFormat),
    filename: path.join(
      __dirname,
      "../",
      "../",
      "logs",
      `${config.ENV}-info.log`
    ),
  });
};
const errorFileTransport = (): FileTransportInstance => {
  return new transports.File({
    level: "error",
    format: format.combine(format.timestamp(), fileLogFormat),
    filename: path.join(
      __dirname,
      "../",
      "../",
      "logs",
      `${config.ENV}-error.log`
    ),
  });
};

const mongodbTransport = (): Array<MongoDBTransportInstance> => {
  return [
    new transports.MongoDB({
      level: "info",
      metaKey: "meta",
      collection: "application-logs",
      db: `${config.MONGODB_URL}/${config.DB_NAME}`,
      expireAfterSeconds: 3600 * 24 * 30,
    }),
  ];
};

export default createLogger({
  defaultMeta: {
    meta: {},
  },
  transports: [
    infoFileTransport(),
    errorFileTransport(),
    ...mongodbTransport(),
    ...consoleTransport(),
  ],
});
