/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { ApiError, Storage, type UploadResponse } from "@google-cloud/storage";
import config from "../config/config";
import fs from "fs";
import logger from "./logger";
// import sharp from "sharp";

const storage = new Storage({ keyFilename: "keys.json" });

async function UploadBuckethandler(file: Express.Multer.File, dest: string) {
  try {
    const bucket = storage.bucket(config.BUCKET_NAME);

    const destination = `News/${dest}/${file.filename}`;

    // await sharp(file)
    //   .resize({ width: 800 }) // Resize width to 800px (optional)
    //   .jpeg({ quality: 80 }) // Compress JPEG to 80% quality
    //   .toFile(outputPath);
    const data: UploadResponse = await bucket.upload(file.path, {
      destination,
      resumable: true,
      metadata: {
        contentType: file.mimetype,
      },
    });

    fs.unlink(file.path, (err) => {
      if (err) {
        logger.error("Error deleting file", err);
      }
    });

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const fileData = data[1] as any;

    const URL = `https://storage.googleapis.com/${String(fileData.bucket)}/${fileData.name}`;
    return { URL, uploadID: fileData.name };
  } catch (error) {
    fs.unlinkSync(file.path);
    if (error instanceof ApiError) {
      logger.error("Cloud Bucket Error-UploadBuckethandler", error);
    }
    return;
  }
}

async function DeleteBucketFile(id: string) {
  try {
    const file = storage.bucket(config.BUCKET_NAME).file(id);
    const [exists] = await file.exists();
    if (!exists) {
      logger.error("Cloud Bucket Delete File Error", exists);
      return `File does not exist`;
    }
    await file.delete();
    return `Deleted Successfully`;
  } catch (error) {
    if (error instanceof ApiError) {
      logger.error("Cloud Bucket Error-DeleteBucketFile", error);
      return `Failed to Delete File`;
    }
    return `Failed to Delete File`;
  }
}

async function listFilesHandler() {
  try {
    const bucket = storage.bucket(config.BUCKET_NAME);
    const [files] = await bucket.getFiles({ prefix: "news" });
    const fileList = files.map((file) => ({
      name: file.name,
      url: `https://storage.googleapis.com/${file.bucket.name}/${file.name}`,
    }));
    return fileList;
  } catch (error) {
    if (error instanceof ApiError) {
      logger.error("Cloud Bucket Error-listFilesHandler", error);
      return `Failed to load File`;
    }
    return `Failed to load File`;
  }
}

export { UploadBuckethandler, DeleteBucketFile, listFilesHandler };
