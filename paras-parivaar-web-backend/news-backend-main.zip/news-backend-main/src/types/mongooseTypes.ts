import { Document, Types } from "mongoose";

//Types for Category
interface ICategory extends Document {
  name: string;
}

//Types for SubCategory
interface ISubCategory extends Document {
  name: string;
  categoryId: Types.ObjectId;
}

//Types for News
interface INews extends Document {
  title: string;
  slug: string;
  description: string;
  metaDescription: string;
  videoURL: string;
  Image: { ImageID: string; ImageURL: string };
  alt: string;
  tags: [string];
  status: boolean;
  views: number;
  categoryId: Types.ObjectId;
  subCategoryId: Types.ObjectId;
  publisherId: Types.ObjectId;
  anchorId: Types.ObjectId;
}

interface IUser extends Document {
  _id: string;
  name: string;
  email: string;
  isEmailVerified: boolean;
  role: string;
  password: string;
  refreshToken: string;
  isPasswordCorrect(password: string): Promise<boolean>;
  generateAccessToken(): string;
  generateRefreshToken(): string;
}

export type { ICategory, ISubCategory, INews, IUser };
