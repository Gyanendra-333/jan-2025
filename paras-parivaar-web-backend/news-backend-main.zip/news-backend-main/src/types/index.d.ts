import type { IAdmin } from "./mongooseTypes";

declare global {
  namespace Express {
    interface Request {
      user?: IAdmin; // Extend Request with user
    }
  }
}
