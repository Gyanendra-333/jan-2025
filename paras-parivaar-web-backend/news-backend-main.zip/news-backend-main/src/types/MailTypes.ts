type templateDetailType = {
  url: string;
  title: string;
  userName: string;
  OTP: number;
  min: number;
};

type reciverDetail = {
  email: string;
  Sub: string;
};

export type { templateDetailType, reciverDetail };
