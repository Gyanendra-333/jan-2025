import app from "./app";
import config from "./config/config";
import { connectDB } from "./config/DB";
import { initRateLimiter } from "./config/rateLimiter";
import logger from "./utlis/logger";

connectDB()
  .then((connection) => {
    logger.info(`DataBase connected to:-${connection?.db?.databaseName}`);

    initRateLimiter(connection);
    logger.info(`RATE_LIMITER_INITIALIZE`);

    app.listen(config.PORT, () =>
      logger.info(`Server is running on PORT ${config.PORT}`)
    );
  })
  .catch((err) => {
    logger.error("Application Error and mongoDB connection", err);
    // app.on("error", (err) => logger.error("Application Error", err));
    app.listen().close((error) => {
      logger.error("Application Error", error);
      process.exit(1);
    });
  });
