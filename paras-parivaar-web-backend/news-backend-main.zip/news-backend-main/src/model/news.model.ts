import mongoose from "mongoose";
import type { INews } from "../types/mongooseTypes";

const NewsSchema = new mongoose.Schema<INews>(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
    },
    slug: {
      type: String,
      unique: true,
      required: [true, "Slug is required"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Description is required"],
      trim: true,
    },
    metaDescription: {
      type: String,
      required: [true, "MetaDescription is required"],
      trim: true,
    },
    videoURL: {
      type: String,
      trim: true,
    },
    Image: {
      ImageID: {
        type: String,
      },
      ImageURL: {
        type: String,
      },
    },
    alt: {
      type: String,
      trim: true,
    },
    tags: {
      type: [String],
      trim: true,
    },
    status: {
      type: Boolean,
      required: true,
    },
    views: {
      type: Number,
      default: 0,
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "category",
      required: true,
    },
    subCategoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "subcategory",
      default: null,
      required: false,
    },
    publisherId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "publisher",
    },
    anchorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "anchor",
      default: null,
      required: false,
    },
  },
  { timestamps: true }
);

export const NewsModel = mongoose.model<INews>("news", NewsSchema);
