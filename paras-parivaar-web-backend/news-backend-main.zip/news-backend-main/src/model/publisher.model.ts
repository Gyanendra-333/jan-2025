import mongoose, { type InferSchemaType } from "mongoose";

const PublisherSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
      lowercase: true,
      required: [true, "Publisher name field is required"],
    },
  },
  {
    timestamps: true,
  }
);

type IPublisher = InferSchemaType<typeof PublisherSchema>;

export const PublisherModel = mongoose.model<IPublisher>(
  "publisher",
  PublisherSchema
);
