import mongoose, { type InferSchemaType } from "mongoose";

const SubCategorySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
      lowercase: true,
      required: [true, "SubCategory name is required"],
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "category",
      required: true,
    },
  },
  { timestamps: true }
);

SubCategorySchema.index({ categoryId: 1, name: 1 }, { unique: true });

type ISubCategory = InferSchemaType<typeof SubCategorySchema>;

const SubCategoryModel = mongoose.model<ISubCategory>(
  "subcategory",
  SubCategorySchema
);

export { SubCategoryModel };
