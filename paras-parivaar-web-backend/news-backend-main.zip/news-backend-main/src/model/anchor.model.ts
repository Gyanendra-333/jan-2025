import mongoose, { type InferSchemaType } from "mongoose";

const AnchorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
      required: [true, "Anchor field name is required"],
    },
  },
  {
    timestamps: true,
  }
);

type IAnchor = InferSchemaType<typeof AnchorSchema>;
export const AnchorModel = mongoose.model<IAnchor>("anchor", AnchorSchema);
