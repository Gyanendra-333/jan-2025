import mongoose, { type InferSchemaType } from "mongoose";

const ConatctSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      trim: true,
      required: [true, "full name is required"],
    },
    email: {
      type: String,
      trim: true,
      required: [true, "email is required"],
    },
    phone: {
      type: Number,
      trim: true,
      required: [true, "phone is required"],
    },
    message: {
      type: String,
      trim: true,
      required: [true, "message is required"],
    },
  },
  {
    timestamps: true,
  }
);

type IContact = InferSchemaType<typeof ConatctSchema>;
export const ContactModel = mongoose.model<IContact>("contact", ConatctSchema);
