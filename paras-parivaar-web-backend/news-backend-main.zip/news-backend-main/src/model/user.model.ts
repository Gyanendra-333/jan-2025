import mongoose, { type CallbackWithoutResultAndOptionalError } from "mongoose";
import * as jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { type IUser } from "../types/mongooseTypes";
import config from "../config/config";

const UserSchema = new mongoose.Schema<IUser>(
  {
    name: {
      type: String,
      trim: true,
      required: [true, "Admin field is require"],
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    role: {
      type: String,
      required: true,
      trim: true,
      enum: ["admin", "user"],
      default: "user",
    },
    password: {
      type: String,
      required: [true, "Password field is required"],
    },
    refreshToken: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

UserSchema.pre<IUser>(
  "save",
  async function (this: IUser, next: CallbackWithoutResultAndOptionalError) {
    //if password not changed
    if (!this.isModified("password")) return next();

    this.password = await bcrypt.hash(this.password, 10);
    next();
  }
);

UserSchema.methods.isPasswordCorrect = async function (password: string) {
  return await bcrypt.compare(password, this.password as string);
};

UserSchema.methods.generateAccessToken = function (): string {
  return jwt.sign(
    {
      id: this._id as string,
      name: this.name as string,
      email: this.email as string,
      role: this.role as string,
    },
    config.ACCESS_TOKEN_SECRET,
    {
      expiresIn: Number(config.ACCESS_TOKEN_EXPIRY),
    }
  );
};
UserSchema.methods.generateRefreshToken = function (): string {
  return jwt.sign({ id: this._id as string }, config.REFRESH_TOKEN_SECRET, {
    expiresIn: Number(config.ACCESS_TOKEN_EXPIRY),
  });
};

export const UserModel = mongoose.model<IUser>("user", UserSchema);
