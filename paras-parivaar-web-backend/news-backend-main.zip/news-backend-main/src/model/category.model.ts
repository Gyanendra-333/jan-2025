import mongoose from "mongoose";
import type { ICategory } from "../types/mongooseTypes";

const CategorySchema = new mongoose.Schema<ICategory>(
  {
    name: {
      type: String,
      unique: true,
      trim: true,
      lowercase: true,
      required: [true, "Category name is required"],
    },
  },
  { timestamps: true }
);

const CategoryModel = mongoose.model<ICategory>("category", CategorySchema);

export { CategoryModel };
