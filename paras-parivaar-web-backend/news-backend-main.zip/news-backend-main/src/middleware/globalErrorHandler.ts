import type { Request, Response } from "express";
import logger from "../utlis/logger";

export default (req: Request, res: Response) => {
  const errorMeta = {
    method: req.method,
    headers: req.headers,
    originalUrl: req.originalUrl,
    baseUrl: req.baseUrl,
  };

  // Log only the explicitly picked properties.
  logger.error("Route Not Found Failed API Error", errorMeta);

  res.status(400).json({ error: "Route Not Found" });
};
