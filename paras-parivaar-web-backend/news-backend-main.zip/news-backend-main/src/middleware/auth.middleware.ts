import type { NextFunction, Request, Response } from "express";
import { asyncHandler } from "../utlis/asyncHandler";
import { ApiError } from "../utlis/ApiError";
import { UserModel } from "../model/user.model";
import Jwt from "jsonwebtoken";
import config from "../config/config";

const verifyJWT = asyncHandler(
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const token: string | undefined =
        (req.cookies.accessToken as string) ||
        req.header("Authorization")?.replace("Bearer ", "");

      if (!token) {
        return res.status(400).json(new ApiError(400, "Unauthorize User", req));
      }

      const decodedToken = Jwt.verify(token, config.ACCESS_TOKEN_SECRET) as {
        id: string;
      };

      if (!decodedToken) {
        return res.status(400).json(new ApiError(400, "Unauthorize User", req));
      }
      const user = await UserModel.findById(decodedToken.id);
      if (!user) {
        return res
          .status(401)
          .json(new ApiError(401, "Invalid Access Token", req));
      }
      req.user = user;
      return next();
    } catch (error) {
      return res
        .status(500)
        .json(new ApiError(500, "Something went wrong", req, [error]));
    }
  }
);

export default verifyJWT;
