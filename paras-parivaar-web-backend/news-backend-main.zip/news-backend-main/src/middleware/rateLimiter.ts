import type { NextFunction, Request, Response } from "express";
import config from "../config/config";
import { EApplicationEnviroment } from "../constant/application";
import { rateLimiterMongo } from "../config/rateLimiter";
import { ApiError } from "../utlis/ApiError";

class RateLimiter {
  public = (req: Request, res: Response, next: NextFunction): void => {
    if (config.ENV === EApplicationEnviroment.DEVELOPMENT) {
      return next();
    }
    if (rateLimiterMongo) {
      rateLimiterMongo
        .consume(req.ip as string, 1)
        .then(() => next())
        .catch((err) => {
          return res
            .status(500)
            .json(
              new ApiError(
                500,
                "too many request please try after sometime",
                null,
                [JSON.stringify(err)]
              )
            );
        });
    }
  };
  flexible = (req: Request, res: Response, next: NextFunction): void => {
    if (config.ENV === EApplicationEnviroment.DEVELOPMENT) {
      return next();
    }
    if (rateLimiterMongo) {
      rateLimiterMongo
        .consume(req.ip as string, 2)
        .then(() => next())
        .catch((err) => {
          return res
            .status(500)
            .json(
              new ApiError(
                500,
                "too many request please try after sometime",
                null,
                [JSON.stringify(err)]
              )
            );
        });
    }
  };
  strict = (req: Request, res: Response, next: NextFunction): void => {
    if (config.ENV === EApplicationEnviroment.DEVELOPMENT) {
      return next();
    }
    if (rateLimiterMongo) {
      rateLimiterMongo
        .consume(req.ip as string, 3) // Increase consumption to tighten the limit.
        .then(() => next())
        .catch((err) => {
          return res
            .status(500)
            .json(
              new ApiError(
                500,
                "too many request please try after sometime",
                null,
                [JSON.stringify(err)]
              )
            );
        });
    } else {
      next();
    }
  };
}
export default new RateLimiter();
