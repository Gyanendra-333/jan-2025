import type { Request } from "express";
import multer, { type FileFilterCallback, type StorageEngine } from "multer";
const storage: StorageEngine = multer.diskStorage({
  destination: function (_req: Request, _file: Express.Multer.File, cb) {
    cb(null, "./public/temp");
  },
  filename: function (_req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix);
  },
});

const fileFilter = (
  _req: Request,
  file: Express.Multer.File,
  cb: FileFilterCallback
) => {
  const fileTypes = /jpeg|jpg|png|webp/;
  const extname = fileTypes.test(String(file.originalname).toLowerCase());
  const mimetype = fileTypes.test(String(file.mimetype));

  if (extname && mimetype) {
    cb(null, true);
  } else {
    cb(new Error(`Only images are allowed ${fileTypes}`));
  }
};

export const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 500 * 1024,
  },
}).single("image");
