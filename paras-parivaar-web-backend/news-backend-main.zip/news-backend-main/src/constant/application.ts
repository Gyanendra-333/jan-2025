export enum EApplicationEnviroment {
  PRODUCTION = "production",
  DEVELOPMENT = "development",
}
