module.exports = {
  parserOptions: {
    project: ['./tsconfig.json'],
  },
};
